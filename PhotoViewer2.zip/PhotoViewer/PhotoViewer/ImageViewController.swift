//
//  ImageViewController.swift
//  PhotoViewer
//
//  Created by Soumen Rautray on 06/09/19.
//  Copyright © 2019 Soumen Rautray. All rights reserved.
//

import Cocoa

class ImageViewController: NSViewController, NSTableViewDelegate {
    @objc dynamic var imageArray = [Details]()
    @objc dynamic var selectedImageObject : Details = Details()
    @IBOutlet weak var imageTableView: NSTableView!
    
    @IBOutlet weak var favIcon: NSButton!
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    func tableViewSelectionDidChange(_ notification: Notification) {
        let tableView = notification.object as? NSTableView
        if tableView?.selectedRow != nil && tableView?.selectedRow != -1 {
            if let selectedImage = tableView?.selectedRow {
                selectedImageObject = self.imageArray[selectedImage] as Details
            }
        }
    }
    @IBAction func RotateButton(_ sender: Any) {
        let rotatedimage = selectedImageObject.image.rotated(degrees:(90))
        selectedImageObject.image = rotatedimage
    }
    @IBAction func RemoveButtonAction(_ sender: Any) {
        self.imageArray.remove(at: self.imageTableView.selectedRow)
    }

    @IBAction func favoriteAction(_ sender: Any) {
        if self.selectedImageObject.isFav == false {
            self.favIcon.image = NSImage(imageLiteralResourceName: "blackHeart")
            self.selectedImageObject.isFav = true
        }else {
            self.favIcon.image = NSImage(imageLiteralResourceName: "favorite")
            self.selectedImageObject.isFav = false
        }
    }
    
    @IBAction func AddActionButton(_ sender: Any) {
        
        if let url = NSOpenPanel().selectUrl {
            selectedImageObject.image = NSImage(contentsOf: url)!
            let imageDetails: Details = Details()
            imageDetails.photoName = ((url.path).components(separatedBy: "/").last?.components(separatedBy: ".").first)!
            imageDetails.path = url.path
            imageDetails.image = NSImage(contentsOf: url)!
            let imageHeight = NSImage(contentsOf: url)!.size.height
            let imageWidth = NSImage(contentsOf: url)!.size.width
            imageDetails.size = "\(imageWidth)x\(imageHeight)"
            imageDetails.format = ((url.path).components(separatedBy: "/").last?.components(separatedBy: ".").last)!
            imageArray.append(imageDetails)

        } else {
            print("file selection was canceled")
        }
    }
}

public extension NSImage {
    func rotated(degrees:CGFloat) -> NSImage {
        let img = NSImage(size: self.size, flipped: false, drawingHandler: { (rect) -> Bool in
            let (width, height) = (rect.size.width, rect.size.height)
            let transform = NSAffineTransform()
            transform.translateX(by: width / 2, yBy: height / 2)
            transform.rotate(byDegrees: degrees)
            transform.translateX(by: -width / 2, yBy: -height / 2)
            transform.concat()
            self.draw(in: rect)
            return true
        })
        img.isTemplate = self.isTemplate // preserve the underlying image's template setting
        return img
    }
}

public extension NSOpenPanel {
    var selectUrl: URL? {
        title = "Select Image"
        allowsMultipleSelection = false
        canChooseDirectories = false
        canChooseFiles = true
        canCreateDirectories = false
        allowedFileTypes = ["jpg","jpeg","png","pdf","pct", "bmp", "tiff"]  //
        return runModal() == .OK ? urls.first : nil
    }
}
